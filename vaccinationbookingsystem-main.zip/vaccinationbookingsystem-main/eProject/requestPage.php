<?php
include('header_admin.php')
?>
<?php
include('requestRegisteration.php')
?>
<?php
include('requestAppointment.php')
?>

<script src="js/script.js"></script>

<?php
include('footer.php')
?>
