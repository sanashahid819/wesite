<?php

function redirectWindow($url){
echo "<script>window.location.href='".getRoot()."$url'</script>";
}

?>